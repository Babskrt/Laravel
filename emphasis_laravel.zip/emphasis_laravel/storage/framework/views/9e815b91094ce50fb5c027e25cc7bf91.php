
</body>
</html><?php /**PATH D:\emphasis_laravel\resources\views/templates/footer.blade.php ENDPATH**/ ?>