<table border ='1'>
        <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Description</th>
            <th>Image</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="/product_details/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></td>
            <td><?php echo e($product->quantity); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->description); ?></td>
            <td><img src="<?php echo e($product->imageUrl); ?>" width ="50"></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php /**PATH D:\emphasis_laravel\resources\views/components/products.blade.php ENDPATH**/ ?>