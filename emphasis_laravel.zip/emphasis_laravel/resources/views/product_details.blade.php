@include('templates.header')

<x-navBar/>
<h2>Product Details</h2>

<img src="{{$product-imageUrl}}">

<h3>Product Name:{{$product->name}}</h3>

<x-products :products=$products>
@include('templates.footer')