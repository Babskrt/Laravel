<table border ='1'>
        <tr>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Description</th>
            <th>Image</th>
        </tr>
        @foreach($products as $product)
        <tr>
            <td><a href="/product_details/{{$product->id}}">{{$product->name}}</td>
            <td>{{$product->quantity}}</td>
            <td>{{$product->price}}</td>
            <td>{{$product->description}}</td>
            <td><img src="{{$product->imageUrl}}" width ="50"></td>
        </tr>
        @endforeach
    </table>
